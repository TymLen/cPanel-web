$(document).ready(function(){
    startSlideShow();
});