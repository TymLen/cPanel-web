<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-GB" lang="en-GB">
  <head>
    <meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/stylesheet.css" />
    <title>Protyme Underconstruction</title>
  </head>
  <body>	
	<header>
			<?php include '../php/header.php';?>
	</header>	
	<article>
		<p id="info">
			This is where information about my courses is hosted. <br><br>
			This page is still under construction.
		</p>
		<?php include '../php/allcourse.php';?>
	</article>
	<footer><?php include '../php/footer.php';?></footer>
  </body>
</html>
