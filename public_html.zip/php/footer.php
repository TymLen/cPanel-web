<?php
echo'<p>© Tymothy Lenton '.date("Y").' All rights reserved.</p>';
echo'<p>All logos, trademarks and registered trademarks are the property of their respective owners.<p>';
?> 