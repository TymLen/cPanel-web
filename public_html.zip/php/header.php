<?php
	echo'<a href="../index.php"><img class = "banner" src = "../img/bannertextAlt2.png" alt="Banner Text"></a>';
		echo'<div class="navbar">';
					echo'<a href="../html/projects.php">Projects</a>';
					echo'<a href="../html/designs.php">Designs</a>';
					echo'<a href="../html/edu.php">Education</a>';
		echo'</div>';
?> 